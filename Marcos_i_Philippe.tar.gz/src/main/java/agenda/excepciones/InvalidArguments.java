package agenda.excepciones;

public class InvalidArguments extends Exception {
    public InvalidArguments(){
        super("Argumento/s no válido/s");
    }
}
