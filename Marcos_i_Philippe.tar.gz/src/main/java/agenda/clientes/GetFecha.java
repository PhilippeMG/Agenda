package agenda.clientes;

import java.time.LocalDateTime;

public interface GetFecha {
    LocalDateTime getFecha();
}
